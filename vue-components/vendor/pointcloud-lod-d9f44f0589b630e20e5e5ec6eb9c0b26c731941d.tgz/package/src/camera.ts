/**
 * Pure camera math for LOD selection: frustum extraction/culling from a
 * column-major view-projection matrix and screen-space error estimation.
 * No vtk.js imports — callers hand in plain arrays, so the module works in
 * any renderer, worker, or test without a GL context.
 */

import { finitePositive } from "./numeric";
import type { Bounds, Vec3 } from "./octree";

/** Column-major 4x4 matrix, OpenGL layout (translation in indices 12..14). */
export type Mat16 = ArrayLike<number>;

/** Frozen: it is handed out as the default placement, not a scratch buffer. */
export const IDENTITY: readonly number[] = Object.freeze([
  1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
]);

type CameraViewCommon = {
  /** Column-major view-projection matrix. */
  readonly viewProj: Mat16;
  /** Camera position in world coordinates. */
  readonly position: Vec3;
  /** Viewport width in CSS pixels. */
  readonly viewportWidthCssPx: number;
  /** Viewport height in CSS pixels. */
  readonly viewportHeightCssPx: number;
};

export type PerspectiveCameraView = CameraViewCommon & {
  readonly projection: "perspective";
  /** Vertical field of view, radians. */
  readonly fovY: number;
};

export type OrthographicCameraView = CameraViewCommon & {
  readonly projection: "orthographic";
  /** World-space half-height of the viewport (vtk.js `parallelScale`). */
  readonly parallelScale: number;
};

/**
 * The two projections turn a world spacing into pixels by different laws, and
 * no numeric value in the view distinguishes them, so the mode is carried
 * explicitly rather than inferred.
 */
export type CameraView = PerspectiveCameraView | OrthographicCameraView;

/** Half-space `dot(normal, p) + d >= 0` containing the frustum interior. */
export type Plane = {
  readonly normal: Vec3;
  readonly d: number;
};

const plane = (a: number, b: number, c: number, d: number): Plane | null => {
  const length = Math.hypot(a, b, c);
  if (length === 0) return null;
  return { normal: [a / length, b / length, c / length], d: d / length };
};

/**
 * Gribb–Hartmann frustum extraction. Degenerate planes (zero normal) are
 * dropped, so an identity matrix yields the NDC cube's six half-spaces.
 */
export const frustumPlanes = (m: Mat16): Plane[] => {
  const row = (i: number): [number, number, number, number] => [
    m[i]!,
    m[i + 4]!,
    m[i + 8]!,
    m[i + 12]!,
  ];
  const [r0, r1, r2, r3] = [row(0), row(1), row(2), row(3)];
  const candidates = [
    plane(r3[0] + r0[0], r3[1] + r0[1], r3[2] + r0[2], r3[3] + r0[3]), // left
    plane(r3[0] - r0[0], r3[1] - r0[1], r3[2] - r0[2], r3[3] - r0[3]), // right
    plane(r3[0] + r1[0], r3[1] + r1[1], r3[2] + r1[2], r3[3] + r1[3]), // bottom
    plane(r3[0] - r1[0], r3[1] - r1[1], r3[2] - r1[2], r3[3] - r1[3]), // top
    plane(r3[0] + r2[0], r3[1] + r2[1], r3[2] + r2[2], r3[3] + r2[3]), // near
    plane(r3[0] - r2[0], r3[1] - r2[1], r3[2] - r2[2], r3[3] - r2[3]), // far
  ];
  return candidates.filter((p): p is Plane => p !== null);
};

/**
 * Conservative AABB-vs-frustum test using the positive-vertex distance: true
 * when the bounds may intersect the frustum, false only when they are fully
 * outside at least one plane.
 */
export const boundsIntersectsFrustum = (
  planes: readonly Plane[],
  bounds: Bounds,
): boolean => {
  for (const { normal, d } of planes) {
    const x = normal[0] >= 0 ? bounds.max[0] : bounds.min[0];
    const y = normal[1] >= 0 ? bounds.max[1] : bounds.min[1];
    const z = normal[2] >= 0 ? bounds.max[2] : bounds.min[2];
    const distance = normal[0] * x + normal[1] * y + normal[2] * z + d;
    if (distance < 0) return false;
  }
  return true;
};

/** Distance from a point to the surface of an AABB; 0 inside. */
export const distanceToBounds = (point: Vec3, bounds: Bounds): number => {
  const dx = Math.max(bounds.min[0] - point[0], 0, point[0] - bounds.max[0]);
  const dy = Math.max(bounds.min[1] - point[1], 0, point[1] - bounds.max[1]);
  const dz = Math.max(bounds.min[2] - point[2], 0, point[2] - bounds.max[2]);
  return Math.hypot(dx, dy, dz);
};

/**
 * Projected size of a world-space spacing, in pixels, under perspective
 * projection: how far apart this node's points land on screen. Distance is
 * clamped so a camera inside the node reports a very large (never infinite)
 * error.
 */
export const perspectiveScreenSpaceError = (
  spacing: number,
  distance: number,
  viewportHeightCssPx: number,
  fovY: number,
): number =>
  (spacing * viewportHeightCssPx) /
  (2 * Math.max(distance, 1e-9) * Math.tan(fovY / 2));

/**
 * Projected size of a world-space spacing, in pixels, under parallel
 * projection. Distance does not appear: every point projects at the same
 * scale, fixed only by how much world height the viewport spans. Scale is
 * clamped for the same reason distance is above.
 */
export const orthographicScreenSpaceError = (
  spacing: number,
  viewportHeightCssPx: number,
  parallelScale: number,
): number =>
  (spacing * viewportHeightCssPx) / (2 * Math.max(parallelScale, 1e-9));

/**
 * Screen-space error of one octree node, under whichever projection the view
 * declares: its level's point spacing projected at the node's distance from
 * the camera, or — under a parallel camera, where distance does not enter the
 * law at all — at the world height the viewport spans.
 */
export const nodeScreenSpaceError = (
  bounds: Bounds,
  spacing: number,
  view: CameraView,
): number =>
  view.projection === "orthographic"
    ? orthographicScreenSpaceError(
        spacing,
        view.viewportHeightCssPx,
        view.parallelScale,
      )
    : perspectiveScreenSpaceError(
        spacing,
        distanceToBounds(view.position, bounds),
        view.viewportHeightCssPx,
        view.fovY,
      );

/**
 * A homogeneous w at or below this is unusable: the point sits at or behind
 * the projective horizon and dividing by w yields nothing meaningful.
 */
export const CLIP_W_EPSILON = 1e-9;

export type ProjectedPointCssPx = {
  /** Horizontal css-pixel position, origin at the viewport's left edge. */
  readonly xCssPx: number;
  /** Vertical css-pixel position, origin at the viewport's top edge. */
  readonly yCssPx: number;
  /** Normalized device z (`clip.z / clip.w`), for near/far interval tests. */
  readonly ndcZ: number;
};

/**
 * Project a world point through a column-major view-projection matrix into
 * css-pixel viewport coordinates (y down). Returns null when the viewport
 * dimensions are unusable, any clip coordinate is non-finite, or the
 * homogeneous w is at or below `CLIP_W_EPSILON` (at/behind the camera plane).
 */
export const projectPointToCssPx = (
  viewProj: Mat16,
  point: Vec3,
  viewportWidthCssPx: number,
  viewportHeightCssPx: number,
): ProjectedPointCssPx | null => {
  if (
    !finitePositive(viewportWidthCssPx) ||
    !finitePositive(viewportHeightCssPx)
  ) {
    return null;
  }
  const m = viewProj;
  const [x, y, z] = point;
  const clipX = m[0]! * x + m[4]! * y + m[8]! * z + m[12]!;
  const clipY = m[1]! * x + m[5]! * y + m[9]! * z + m[13]!;
  const clipZ = m[2]! * x + m[6]! * y + m[10]! * z + m[14]!;
  const clipW = m[3]! * x + m[7]! * y + m[11]! * z + m[15]!;
  if (
    !Number.isFinite(clipX) ||
    !Number.isFinite(clipY) ||
    !Number.isFinite(clipZ) ||
    !Number.isFinite(clipW) ||
    clipW <= CLIP_W_EPSILON
  ) {
    return null;
  }
  return {
    xCssPx: ((clipX / clipW + 1) / 2) * viewportWidthCssPx,
    yCssPx: ((1 - clipY / clipW) / 2) * viewportHeightCssPx,
    ndcZ: clipZ / clipW,
  };
};

export type CursorRay = {
  /** The cursor unprojected onto the near plane. */
  readonly origin: Vec3;
  /** Unit direction from the near-plane point towards the far plane. */
  readonly direction: Vec3;
};

/** Cofactor inverse of a column-major 4x4; null when singular or non-finite. */
const invert4 = (m: Mat16): number[] | null => {
  const a00 = m[0]!,
    a01 = m[1]!,
    a02 = m[2]!,
    a03 = m[3]!;
  const a10 = m[4]!,
    a11 = m[5]!,
    a12 = m[6]!,
    a13 = m[7]!;
  const a20 = m[8]!,
    a21 = m[9]!,
    a22 = m[10]!,
    a23 = m[11]!;
  const a30 = m[12]!,
    a31 = m[13]!,
    a32 = m[14]!,
    a33 = m[15]!;

  const b00 = a00 * a11 - a01 * a10;
  const b01 = a00 * a12 - a02 * a10;
  const b02 = a00 * a13 - a03 * a10;
  const b03 = a01 * a12 - a02 * a11;
  const b04 = a01 * a13 - a03 * a11;
  const b05 = a02 * a13 - a03 * a12;
  const b06 = a20 * a31 - a21 * a30;
  const b07 = a20 * a32 - a22 * a30;
  const b08 = a20 * a33 - a23 * a30;
  const b09 = a21 * a32 - a22 * a31;
  const b10 = a21 * a33 - a23 * a31;
  const b11 = a22 * a33 - a23 * a32;

  const det =
    b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06;
  if (!Number.isFinite(det) || det === 0) return null;
  const d = 1 / det;

  const inverse = [
    (a11 * b11 - a12 * b10 + a13 * b09) * d,
    (a02 * b10 - a01 * b11 - a03 * b09) * d,
    (a31 * b05 - a32 * b04 + a33 * b03) * d,
    (a22 * b04 - a21 * b05 - a23 * b03) * d,
    (a12 * b08 - a10 * b11 - a13 * b07) * d,
    (a00 * b11 - a02 * b08 + a03 * b07) * d,
    (a32 * b02 - a30 * b05 - a33 * b01) * d,
    (a20 * b05 - a22 * b02 + a23 * b01) * d,
    (a10 * b10 - a11 * b08 + a13 * b06) * d,
    (a01 * b08 - a00 * b10 - a03 * b06) * d,
    (a30 * b04 - a31 * b02 + a33 * b00) * d,
    (a21 * b02 - a20 * b04 - a23 * b00) * d,
    (a11 * b07 - a10 * b09 - a12 * b06) * d,
    (a00 * b09 - a01 * b07 + a02 * b06) * d,
    (a31 * b01 - a30 * b03 - a32 * b00) * d,
    (a20 * b03 - a21 * b01 + a22 * b00) * d,
  ];
  for (const value of inverse) {
    if (!Number.isFinite(value)) return null;
  }
  return inverse;
};

/** `inverse * [ndc, 1]`, homogenized; null when w collapses or goes wild. */
const unprojectNdc = (
  inverse: readonly number[],
  ndcX: number,
  ndcY: number,
  ndcZ: number,
): Vec3 | null => {
  const x =
    inverse[0]! * ndcX + inverse[4]! * ndcY + inverse[8]! * ndcZ + inverse[12]!;
  const y =
    inverse[1]! * ndcX + inverse[5]! * ndcY + inverse[9]! * ndcZ + inverse[13]!;
  const z =
    inverse[2]! * ndcX +
    inverse[6]! * ndcY +
    inverse[10]! * ndcZ +
    inverse[14]!;
  const w =
    inverse[3]! * ndcX +
    inverse[7]! * ndcY +
    inverse[11]! * ndcZ +
    inverse[15]!;
  if (!Number.isFinite(w) || Math.abs(w) <= CLIP_W_EPSILON) return null;
  const point: Vec3 = [x / w, y / w, z / w];
  for (const coordinate of point) {
    if (!Number.isFinite(coordinate)) return null;
  }
  return point;
};

/**
 * The world-space ray under a css-pixel cursor: invert the view-projection,
 * unproject the cursor at NDC z = -1 and z = +1, and normalize `far - near`.
 * One definition serves perspective and orthographic views alike. Returns
 * null when the matrix is singular or non-finite, the viewport dimensions are
 * unusable, or the cursor is non-finite.
 */
export const cursorRay = (
  viewProj: Mat16,
  cursorXCssPx: number,
  cursorYCssPx: number,
  viewportWidthCssPx: number,
  viewportHeightCssPx: number,
): CursorRay | null => {
  if (
    !Number.isFinite(cursorXCssPx) ||
    !Number.isFinite(cursorYCssPx) ||
    !finitePositive(viewportWidthCssPx) ||
    !finitePositive(viewportHeightCssPx)
  ) {
    return null;
  }
  const inverse = invert4(viewProj);
  if (inverse === null) return null;
  const ndcX = (2 * cursorXCssPx) / viewportWidthCssPx - 1;
  const ndcY = 1 - (2 * cursorYCssPx) / viewportHeightCssPx;
  const near = unprojectNdc(inverse, ndcX, ndcY, -1);
  const far = unprojectNdc(inverse, ndcX, ndcY, 1);
  if (near === null || far === null) return null;
  const dx = far[0] - near[0];
  const dy = far[1] - near[1];
  const dz = far[2] - near[2];
  const length = Math.hypot(dx, dy, dz);
  if (!Number.isFinite(length) || length <= 0) return null;
  return {
    origin: near,
    direction: [dx / length, dy / length, dz / length],
  };
};

/**
 * Angular offset between a node's 3D centre and the camera's centre ray.
 * Zero is the innermost cone; larger values form concentric cones moving away
 * from the view centre. Selection only compares nodes at the same octree
 * level, where their bounds have equal size, so centres give the unblurred
 * spatial order without large coarse bounding spheres masking one another.
 *
 * Perspective views return radians. Parallel views have no angular spread,
 * so they return perpendicular world-space clearance normalized by the
 * viewport half-height. Both are dimensionless and ordered centre-out; their
 * magnitudes are never compared across different camera views.
 */
export const boundsCenterRayOffset = (
  bounds: Bounds,
  view: CameraView,
): number => {
  const ray = cursorRay(
    view.viewProj,
    view.viewportWidthCssPx / 2,
    view.viewportHeightCssPx / 2,
    view.viewportWidthCssPx,
    view.viewportHeightCssPx,
  );
  if (ray === null) return Number.POSITIVE_INFINITY;

  const center: Vec3 = [
    (bounds.min[0] + bounds.max[0]) / 2,
    (bounds.min[1] + bounds.max[1]) / 2,
    (bounds.min[2] + bounds.max[2]) / 2,
  ];
  let origin = ray.origin;
  if (view.projection === "perspective") {
    // A valid perspective eye lies on the centre line recovered from the
    // matrix. Prefer the explicit eye (the cone's true apex), but keep the
    // matrix-derived point when an untyped host supplies an inconsistent eye
    // and matrix rather than inventing a skewed centre ray.
    const eyeDx = view.position[0] - ray.origin[0];
    const eyeDy = view.position[1] - ray.origin[1];
    const eyeDz = view.position[2] - ray.origin[2];
    const eyeAlong =
      eyeDx * ray.direction[0] +
      eyeDy * ray.direction[1] +
      eyeDz * ray.direction[2];
    const eyeDistanceSquared = eyeDx * eyeDx + eyeDy * eyeDy + eyeDz * eyeDz;
    const eyeOffAxis = Math.sqrt(
      Math.max(0, eyeDistanceSquared - eyeAlong * eyeAlong),
    );
    if (eyeOffAxis <= 1e-9 * Math.max(1, Math.sqrt(eyeDistanceSquared))) {
      origin = view.position;
    }
  }
  const dx = center[0] - origin[0];
  const dy = center[1] - origin[1];
  const dz = center[2] - origin[2];
  const along =
    dx * ray.direction[0] + dy * ray.direction[1] + dz * ray.direction[2];
  const distanceSquared = dx * dx + dy * dy + dz * dz;
  const perpendicular = Math.sqrt(Math.max(0, distanceSquared - along * along));

  if (view.projection === "orthographic") {
    return perpendicular / view.parallelScale;
  }

  const distance = Math.sqrt(distanceSquared);
  if (distance === 0) return 0;
  return Math.atan2(perpendicular, along);
};

/**
 * Camera-motion comparison for the inferred-motion classifier: did this view
 * move, beyond recomputation jitter, relative to a previously rendered one?
 *
 * The epsilon is relative with an absolute floor of the same size, because
 * the compared numbers span map-projection units (~1) and metric frames
 * (~1e6) in the same matrix. Recomputing a double-precision camera product
 * every frame moves the last bits — a few 1e-16 of the terms behind each
 * entry — while the smallest camera change that moves a pixel sits orders
 * above 1e-9, so recomputation jitter never enters the moving regime and no
 * real motion is missed. Entries that are small differences of huge terms
 * would eat that margin; the one place a rendered matrix does that, a
 * scene-derived clip depth range, is excluded from the comparison entirely
 * (see MOTION_MATRIX_INDICES).
 */
const MOTION_RELATIVE_EPSILON = 1e-9;

const movedBeyondJitter = (previous: number, next: number): boolean =>
  Math.abs(previous - next) >
  MOTION_RELATIVE_EPSILON * Math.max(1, Math.abs(previous), Math.abs(next));

/**
 * The `viewProj` entries that describe where the camera is looking, in the
 * column-major layout (`index = column * 4 + row`). The clip-z row
 * (2, 6, 10, 14) is deliberately left out: hosts fold a depth remap derived
 * from the scene's visible bounds into it, so a tile arriving or being
 * evicted rewrites those four numbers while the camera stands perfectly
 * still. Everything a camera move does to the rendered image shows up in the
 * x, y and w rows; the one motion that lives only in clip z — dollying an
 * orthographic camera along its view axis — shows up in the eye point, which
 * is compared alongside the matrix.
 */
const MOTION_MATRIX_INDICES = [0, 1, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15];

/** The projection's own sizing scalar, whichever kind of projection it is. */
const projectionSizingScalar = (view: CameraView): number =>
  view.projection === "orthographic" ? view.parallelScale : view.fovY;

/**
 * Whether `next` renders a genuinely different camera than `previous`.
 * A missing `previous` is a baseline being established, not a movement.
 *
 * Compared entry by entry and answered at the first difference: this runs on
 * every rendered frame of every view, and the overwhelmingly common answer —
 * a camera that has not moved — is the one case that must read all of them.
 * What is compared is everything about the camera that changes what LOD
 * selects: where it looks from and at, the eye point, the viewport height
 * screen-space error is measured in, and the projection's sizing scalar.
 */
export const cameraMoved = (
  previous: CameraView | null | undefined,
  next: CameraView,
): boolean => {
  if (!previous) return false;
  if (previous.projection !== next.projection) return true;
  for (const index of MOTION_MATRIX_INDICES) {
    if (
      movedBeyondJitter(
        Number(previous.viewProj[index]),
        Number(next.viewProj[index]),
      )
    ) {
      return true;
    }
  }
  for (let axis = 0; axis < 3; axis += 1) {
    if (movedBeyondJitter(previous.position[axis]!, next.position[axis]!)) {
      return true;
    }
  }
  return (
    movedBeyondJitter(previous.viewportHeightCssPx, next.viewportHeightCssPx) ||
    movedBeyondJitter(
      projectionSizingScalar(previous),
      projectionSizingScalar(next),
    )
  );
};

/**
 * A model transform tiles draw under, resolved once: the matrix, its inverse,
 * and the uniform scale of the similarity. The frustum/SSE math in this
 * module assumes a uniform-scale transform — an affine bottom row, orthogonal
 * columns, equal column lengths — so a matrix that is not a similarity has no
 * usable frame and resolves to null.
 */
export type ModelFrame = {
  readonly matrix: readonly number[];
  readonly inverse: readonly number[];
  readonly scale: number;
};

/**
 * The uniform scale of a similarity transform, or null when the matrix is
 * not one.
 */
const similarityScale = (m: Mat16): number | null => {
  if (m.length !== 16) return null;
  for (let index = 0; index < 16; index += 1) {
    if (!Number.isFinite(m[index]!)) return null;
  }
  if (
    Math.abs(m[3]!) > 1e-9 ||
    Math.abs(m[7]!) > 1e-9 ||
    Math.abs(m[11]!) > 1e-9 ||
    Math.abs(m[15]! - 1) > 1e-9
  ) {
    return null;
  }
  const columns: Vec3[] = [
    [m[0]!, m[1]!, m[2]!],
    [m[4]!, m[5]!, m[6]!],
    [m[8]!, m[9]!, m[10]!],
  ];
  const lengths = columns.map((column) => Math.hypot(...column));
  const scale = lengths[0]!;
  const tolerance = Math.max(1e-9, scale * 1e-6);
  if (
    !finitePositive(scale) ||
    lengths.some((length) => Math.abs(length - scale) > tolerance)
  ) {
    return null;
  }
  for (let left = 0; left < 3; left += 1) {
    for (let right = left + 1; right < 3; right += 1) {
      const dot = columns[left]!.reduce(
        (sum, value, axis) => sum + value * columns[right]![axis]!,
        0,
      );
      if (Math.abs(dot) > scale * tolerance) return null;
    }
  }
  return scale;
};

/** Column-major product `a × b`. */
export const multiply4 = (a: Mat16, b: Mat16): number[] => {
  // prettier-ignore
  const out: number[] = [
    0, 0, 0, 0,
    0, 0, 0, 0,
    0, 0, 0, 0,
    0, 0, 0, 0,
  ];
  for (let column = 0; column < 4; column += 1) {
    for (let row = 0; row < 4; row += 1) {
      out[column * 4 + row] =
        a[row]! * b[column * 4]! +
        a[4 + row]! * b[column * 4 + 1]! +
        a[8 + row]! * b[column * 4 + 2]! +
        a[12 + row]! * b[column * 4 + 3]!;
    }
  }
  return out;
};

/** Apply an affine column-major matrix to a point. */
export const transformPointBy = (m: Mat16, point: Vec3): Vec3 => [
  m[0]! * point[0] + m[4]! * point[1] + m[8]! * point[2] + m[12]!,
  m[1]! * point[0] + m[5]! * point[1] + m[9]! * point[2] + m[13]!,
  m[2]! * point[0] + m[6]! * point[1] + m[10]! * point[2] + m[14]!,
];

/** Resolve a model matrix into a frame, or null when it is not a similarity. */
export const modelFrameOf = (m: Mat16): ModelFrame | null => {
  const scale = similarityScale(m);
  if (scale === null) return null;
  const inverse = invert4(m);
  if (inverse === null) return null;
  return { matrix: Array.from(m), inverse, scale };
};

/**
 * Restate a world camera in the model's local frame, where the octree's
 * bounds and spacings live. Perspective screen-space error is a ratio of two
 * lengths, so the uniform model scale cancels out of it. Parallel projection
 * has no such ratio: parallelScale is an absolute world height and must be
 * restated in model units alongside the spacings it is compared against.
 */
export const viewInModelFrame = (
  view: CameraView,
  frame: ModelFrame,
): CameraView => {
  const local = {
    ...view,
    viewProj: multiply4(view.viewProj, frame.matrix),
    position: transformPointBy(frame.inverse, view.position),
  };
  return local.projection === "orthographic"
    ? { ...local, parallelScale: local.parallelScale / frame.scale }
    : local;
};

/**
 * The projection's own scalar: field of view, or parallel scale.
 *
 * Returned as `undefined` for an unrecognized discriminant so a bad value
 * reads as absent rather than being silently treated as perspective.
 */
export const projectionScalar = (view: CameraView): number | undefined =>
  view.projection === "perspective"
    ? view.fovY
    : view.projection === "orthographic"
      ? view.parallelScale
      : undefined;

/**
 * Whether two camera views would produce identical selection work.
 *
 * Hosts restate the camera every frame whether or not it moved, so a member
 * that acts on every restatement re-traverses its whole hierarchy while the
 * user is doing nothing — and, because that happens inside the span the host
 * times, inflates the governor's own frame sample and drives quality down.
 */
export const sameCameraView = (a: CameraView, b: CameraView): boolean => {
  if (
    a.projection !== b.projection ||
    projectionScalar(a) !== projectionScalar(b) ||
    a.viewportWidthCssPx !== b.viewportWidthCssPx ||
    a.viewportHeightCssPx !== b.viewportHeightCssPx ||
    a.position[0] !== b.position[0] ||
    a.position[1] !== b.position[1] ||
    a.position[2] !== b.position[2] ||
    a.viewProj.length !== b.viewProj.length
  ) {
    return false;
  }
  for (let index = 0; index < a.viewProj.length; index += 1) {
    if (a.viewProj[index] !== b.viewProj[index]) return false;
  }
  return true;
};

/** Element-wise matrix equality, treating null as its own value. */
export const sameMatrix = (a: Mat16 | null, b: Mat16 | null): boolean => {
  if (a === null || b === null) return a === null && b === null;
  if (a.length !== b.length) return false;
  for (let index = 0; index < a.length; index += 1) {
    if (a[index] !== b[index]) return false;
  }
  return true;
};

/**
 * `base · translate(origin)`: only the last column differs from `base`.
 *
 * Tile geometry is stored relative to a tile origin, so every tile actor's
 * matrix is the member's placement with that origin folded in.
 */
export const translatedMatrix = (base: Mat16, origin: Vec3): number[] => {
  const out = Array.from(base);
  for (let row = 0; row < 4; row += 1) {
    out[12 + row] =
      base[row]! * origin[0] +
      base[4 + row]! * origin[1] +
      base[8 + row]! * origin[2] +
      base[12 + row]!;
  }
  return out;
};

/** Screen-space extent of a projected box, css pixels, y down. */
export type ScreenAabbCssPx = {
  readonly minXCssPx: number;
  readonly minYCssPx: number;
  readonly maxXCssPx: number;
  readonly maxYCssPx: number;
};

/**
 * Screen AABB of the 8 corners of `bounds`, placed by `matrix` first when one
 * is given. Null when any corner is unprojectable (behind the camera plane or
 * non-finite): a pick prefilter must read that as "may be under the cursor",
 * because a wrong skip is an unpickable visible tile.
 */
export const projectedBoundsAabbCssPx = (
  viewProj: Mat16,
  bounds: Bounds,
  viewportWidthCssPx: number,
  viewportHeightCssPx: number,
  matrix: Mat16 | null = null,
): ScreenAabbCssPx | null => {
  let minXCssPx = Number.POSITIVE_INFINITY;
  let minYCssPx = Number.POSITIVE_INFINITY;
  let maxXCssPx = Number.NEGATIVE_INFINITY;
  let maxYCssPx = Number.NEGATIVE_INFINITY;
  for (const x of [bounds.min[0], bounds.max[0]]) {
    for (const y of [bounds.min[1], bounds.max[1]]) {
      for (const z of [bounds.min[2], bounds.max[2]]) {
        const corner: Vec3 = [x, y, z];
        const projected = projectPointToCssPx(
          viewProj,
          matrix === null ? corner : transformPointBy(matrix, corner),
          viewportWidthCssPx,
          viewportHeightCssPx,
        );
        if (projected === null) return null;
        minXCssPx = Math.min(minXCssPx, projected.xCssPx);
        minYCssPx = Math.min(minYCssPx, projected.yCssPx);
        maxXCssPx = Math.max(maxXCssPx, projected.xCssPx);
        maxYCssPx = Math.max(maxYCssPx, projected.yCssPx);
      }
    }
  }
  return { minXCssPx, minYCssPx, maxXCssPx, maxYCssPx };
};
